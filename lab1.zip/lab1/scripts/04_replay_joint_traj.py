import argparse
import time
from xarm_lab.arm_utils import connect_arm, disconnect_arm, ArmConfig
from xarm_lab.traj_io import load_traj
from xarm_lab.safety import enable_basic_safety, clear_faults


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--ip", required=True)
    ap.add_argument("--traj", required=True)
    ap.add_argument("--speed", type=float, default=0.4)
    args = ap.parse_args()

    traj = load_traj(args.traj)
    arm = connect_arm(ArmConfig(ip=args.ip))
    try:
        clear_faults(arm)
        enable_basic_safety(arm)

        for qi in traj.q:
            arm.set_servo_angle(
                angle=qi,
                speed=args.speed,
                wait=False,
                is_radian=True
            )
            time.sleep(0.02)

    finally:
        disconnect_arm(arm)


if __name__ == "__main__":
    main()