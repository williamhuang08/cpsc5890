import argparse
import time
from xarm_lab.arm_utils import connect_arm, disconnect_arm, get_joint_angles, ArmConfig
from xarm_lab.traj_io import JointTrajectory, save_traj


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--ip", required=True)
    ap.add_argument("--out", required=True)
    ap.add_argument("--seconds", type=float, default=8.0)
    ap.add_argument("--hz", type=float, default=50.0)
    args = ap.parse_args()

    arm = connect_arm(ArmConfig(ip=args.ip))
    try:
        t, q = [], []
        start = time.time()
        dt = 1.0 / args.hz

        while time.time() - start < args.seconds:
            t.append(time.time() - start)
            q.append(get_joint_angles(arm))
            time.sleep(dt)

        save_traj(args.out, JointTrajectory(t=t, q=q))
        print(f"Saved {len(t)} waypoints to {args.out}")

    finally:
        disconnect_arm(arm)


if __name__ == "__main__":
    main()