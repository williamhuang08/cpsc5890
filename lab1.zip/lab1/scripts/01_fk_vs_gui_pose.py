import argparse
import numpy as np

from xarm_lab.arm_utils import connect_arm, disconnect_arm, get_joint_angles, get_tcp_pose, ArmConfig
from xarm_lab.kinematics import fk_from_joints


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--ip", required=True)
    args = ap.parse_args()

    arm = connect_arm(ArmConfig(ip=args.ip))
    try:
        q = get_joint_angles(arm)
        gui_pose = np.array(get_tcp_pose(arm))
        fk_pose = np.array(fk_from_joints(arm, q))

        diff = fk_pose - gui_pose

        print("Joint angles:", q)
        print("GUI pose:", gui_pose.tolist())
        print("FK pose:", fk_pose.tolist())
        print("Position error (mm):", np.linalg.norm(diff[:3]))
        print("Orientation error (rad):", np.linalg.norm(diff[3:]))

    finally:
        disconnect_arm(arm)


if __name__ == "__main__":
    main()